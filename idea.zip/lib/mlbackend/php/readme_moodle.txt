Description of php-ml import into mlbackend_php.

The current version is de50490.

Prodedure:
* Get rid of everything else than src/ directory and LICENSE
* Copy src/ and LICENSE into lib/mlbackend/php/phpml/
