Current version is 12b8b11

# Download latest stable version from https://github.com/php-ai/php-ml
# Remove all files but:
   * src/
   * LICENSE
