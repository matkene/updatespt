<?php

$string['thislanguage'] = 'Deutsch';
$string['parentlanguage'] = 'en';
