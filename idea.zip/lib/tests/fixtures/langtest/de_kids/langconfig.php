<?php

$string['thislanguage'] = 'Deutsch - Kids';
$string['parentlanguage'] = 'de_du';
