<?php

$string['thislanguage'] = 'My parent is orphaned language';
$string['parentlanguage'] = 'bb';
