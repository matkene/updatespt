<?php

$string['thislanguage'] = 'Circular dependency B';
$string['parentlanguage'] = 'cda';
