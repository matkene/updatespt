<?php

$string['thislanguage'] = 'Deutsch - Du';
$string['parentlanguage'] = 'de';
