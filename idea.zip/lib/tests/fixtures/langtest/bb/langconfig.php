<?php

$string['thislanguage'] = 'Orphaned language with non-existing parent';
$string['parentlanguage'] = 'bbparent';
