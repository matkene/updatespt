<?php

$string['thislanguage'] = 'AA native name';
$string['thislanguageint'] = 'AA international name';
