<?php
$string['pluginname'] = 'This is a plugin with $plugin->component missing in its version.php';
