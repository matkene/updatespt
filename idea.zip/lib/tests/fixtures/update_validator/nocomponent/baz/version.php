<?php
$plugin->version = 2015080600;
$plugin->release = 'B.A.Z. Auth fake plugin';
// $plugin->component is missing here so the validation must fail.
