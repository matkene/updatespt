<?php
$string['pluginname'] = 'Foo!';
