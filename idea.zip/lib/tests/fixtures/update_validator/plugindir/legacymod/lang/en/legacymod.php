<?php
$string['modulename'] = 'Legacy activity module with $module in version.php';
